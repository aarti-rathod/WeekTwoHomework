/**
 * Created by JANVI on 10/08/2019.
 * 2.	Write a Java program to display the following pattern.

 Sample Pattern :
 J    a   v     v  a
 J   a a   v   v  a a
 J  Jaaaaa   V Vaaaaa
 JJ  a     a   V  a     a

 */
public class SecondHw {

    public static void main(String[] args) {
        System.out.println("Displaying Java Pattern:");
        System.out.println( "    J         a           v        v           a                    " );
        System.out.println( "    J        a  a          v      v           a  a                   " );
        System.out.println( "J   J      a  a a  a        v    v         a  a  a  a                " );
        System.out.println( "J J J    a           a         v         a            a              "  );

    }
}