/**
 * Created by JANVI on 10/08/2019.
 * 3.	 Write a Java program to compute the specified expressions and print the output.
 Test Data:
 ((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5))


 ((10*5)-(20*2))


 Expected Output :  2.138888888888889

 */
public class ThirdHw {

    public static void main (String [] args ){

        System.out.println(((25.5 * 3.5 - 3.5 * 3.5) / (40.5 - 4.5)));

    }
}
